# Latihan 1

# Mata kuliah: Pengolahan Citra Digital
# Nama: Luthfiyyah hanifah amari
# Senin, 13 Feb 2022
# --------------------------------

import cv2

# load an image using 'imread'
img = cv2.imread("alpro2.png")

# display
cv2.imshow("logo alpro", img)
cv2.waitKey(0)